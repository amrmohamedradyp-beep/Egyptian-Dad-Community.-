package com.egyptiandad.prayer

import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AppRoot() {
    var tab by remember { mutableIntStateOf(0) }
    val labels = listOf("المواقيت", "القبلة", "الأذكار", "الصلاة ﷺ", "إنجازي", "الإعدادات")
    val symbols = listOf("◷", "⌖", "۞", "✧", "✓", "⚙")

    Box(modifier = Modifier.fillMaxSize()) {
        GeometricBackground()
        Column(modifier = Modifier.fillMaxSize().safeDrawingPadding()) {
            AppTopBar(section = labels[tab])
            Box(modifier = Modifier.weight(1f)) {
                Crossfade(targetState = tab, animationSpec = tween(250), label = "screen") { page ->
                    when (page) {
                        0 -> TimesScreen()
                        1 -> QiblaScreen()
                        2 -> AdhkarScreen()
                        3 -> SalawatScreen()
                        4 -> StreakScreen()
                        else -> SettingsScreen()
                    }
                }
            }
            GoldBottomBar(selected = tab, labels = labels, symbols = symbols, onSelect = { tab = it })
        }
    }
}

@Composable
private fun AppTopBar(section: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Gold.Surface.copy(alpha = 0.96f))
            .padding(horizontal = 18.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Gold.Gold.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Text("م", color = Gold.Gold, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.width(11.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text("Egyptian Dad Community", color = Gold.Gold, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text(section, color = Gold.Muted, fontSize = 11.sp)
        }
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(Gold.SurfaceHigh)
                .padding(horizontal = 11.dp, vertical = 7.dp)
        ) {
            Text("بِسْمِ الله", color = Gold.GoldLight, fontSize = 11.sp, fontWeight = FontWeight.Medium)
        }
    }
    HorizontalDivider(color = Gold.Line.copy(alpha = 0.8f))
}

@Composable
private fun GoldBottomBar(
    selected: Int,
    labels: List<String>,
    symbols: List<String>,
    onSelect: (Int) -> Unit
) {
    Column {
        HorizontalDivider(color = Gold.Line)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Gold.Surface)
                .padding(horizontal = 3.dp, vertical = 5.dp)
        ) {
            labels.forEachIndexed { index, label ->
                val isSelected = index == selected
                val textColor by animateColorAsState(
                    targetValue = if (isSelected) Gold.Gold else Gold.Muted,
                    label = "tabColor"
                )
                val pillWidth by animateDpAsState(
                    targetValue = if (isSelected) 42.dp else 0.dp,
                    label = "tabPill"
                )
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(13.dp))
                        .clickable { onSelect(index) }
                        .padding(vertical = 6.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .width(pillWidth)
                            .height(27.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) Gold.Gold.copy(alpha = 0.14f) else Gold.Surface),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(symbols[index], color = textColor, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(3.dp))
                    Text(
                        label,
                        color = textColor,
                        fontSize = 9.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        maxLines = 1,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
