package com.egyptiandad.prayer

import java.util.Locale

val arabicLocale: Locale = Locale.forLanguageTag("ar-EG")

/** 5 becomes ٥. */
fun arabicNumber(n: Int): String = String.format(arabicLocale, "%d", n)

fun daysText(n: Int): String = when {
    n == 1 -> "يوم واحد"
    n == 2 -> "يومين"
    n in 3..10 -> arabicNumber(n) + " أيام"
    else -> arabicNumber(n) + " يوم"
}

/** 12345 becomes ١٢٬٣٤٥. */
fun arabicNumber(n: Long): String = String.format(arabicLocale, "%,d", n)
