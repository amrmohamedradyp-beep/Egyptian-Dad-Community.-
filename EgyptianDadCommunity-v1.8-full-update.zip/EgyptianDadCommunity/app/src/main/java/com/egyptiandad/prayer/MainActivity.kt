package com.egyptiandad.prayer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashReporter.install(this)
        val previousCrash = CrashReporter.read(this)
        if (previousCrash != null) {
            CrashReporter.show(this, previousCrash)
            return
        }
        try {
            Notifier.ensureChannel(this)
            Scheduler.scheduleNext(this)
            UiState.textScale = Prefs(this).textScale
        } catch (t: Throwable) {
            CrashReporter.save(this, t)
            CrashReporter.show(this, CrashReporter.read(this) ?: t.toString())
            return
        }
        setContent {
            AppTheme { AppRoot() }
        }
    }
}
