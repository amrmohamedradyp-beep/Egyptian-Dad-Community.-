package com.egyptiandad.prayer

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat

object Notifier {
    /** Default notification sound. Used for the repeated reminders. */
    const val CHANNEL = "prayer_reminders"

    /** Raw audio files that make a muezzin. Put adhan.mp3, adhan_2.mp3 ... in res/raw. */
    private val MUEZZIN_FILES = listOf("adhan", "adhan_2", "adhan_3", "adhan_4", "adhan_5")

    /** Resource ids of the adhan recordings found in the app, in order. Empty if there are none. */
    fun muezzinResIds(context: Context): List<Int> {
        val ids = ArrayList<Int>()
        for (name in MUEZZIN_FILES) {
            val id = context.resources.getIdentifier(name, "raw", context.packageName)
            if (id != 0) ids.add(id)
        }
        return ids
    }

    fun hasAdhan(context: Context): Boolean = muezzinResIds(context).isNotEmpty()

    /** Notification channel of the muezzin with this number, starting at 1. */
    fun adhanChannelId(number: Int): String = if (number <= 1) "prayer_adhan" else "prayer_adhan_$number"

    fun ensureChannel(context: Context) {
        val nm = context.getSystemService(NotificationManager::class.java)

        if (nm.getNotificationChannel(CHANNEL) == null) {
            val channel = NotificationChannel(
                CHANNEL,
                context.getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = context.getString(R.string.channel_description)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(channel)
        }

        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        val ids = muezzinResIds(context)
        for ((index, resId) in ids.withIndex()) {
            val number = index + 1
            val channelId = adhanChannelId(number)
            if (nm.getNotificationChannel(channelId) != null) continue
            val sound = Uri.parse("android.resource://" + context.packageName + "/" + resId)
            val channel = NotificationChannel(
                channelId,
                "أذان الصلاة (المؤذن " + number + ")",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "صوت الأذان عند دخول وقت الصلاة"
                setSound(sound, attributes)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 400, 200, 400)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            nm.createNotificationChannel(channel)
        }
    }

    fun hasPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    fun show(context: Context, key: String, isRepeat: Boolean) {
        if (!hasPermission(context)) return
        ensureChannel(context)

        val prayer = Prayer.valueOf(key.substringAfter(':'))
        val prefs = Prefs(context)
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), flags)
        val prayedIntent = Intent(context, PrayedReceiver::class.java)
            .setAction(PrayedReceiver.ACTION)
            .putExtra(Scheduler.EXTRA_KEY, key)
        val prayed = PendingIntent.getBroadcast(context, key.hashCode(), prayedIntent, flags)

        val available = muezzinResIds(context).size
        val useAdhan = !isRepeat && prefs.adhanOn && prefs.adhanFor(prayer) && available > 0
        val channelId = if (useAdhan) {
            adhanChannelId(prefs.muezzin.coerceIn(1, available))
        } else {
            CHANNEL
        }

        val title = if (isRepeat) "لسه ما صلّيتش ${prayer.arabic}؟" else "حان وقت ${prayer.arabic}"
        val notification = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_stat_prayer)
            .setContentTitle(title)
            .setContentText("قوم صلّي، وبعدين اضغط \"صلّيت\".")
            .setContentIntent(open)
            .setAutoCancel(false)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .addAction(0, "صلّيت", prayed)
            .build()

        NotificationManagerCompat.from(context).notify(key.hashCode(), notification)
    }

    fun cancel(context: Context, key: String) {
        NotificationManagerCompat.from(context).cancel(key.hashCode())
    }
}
