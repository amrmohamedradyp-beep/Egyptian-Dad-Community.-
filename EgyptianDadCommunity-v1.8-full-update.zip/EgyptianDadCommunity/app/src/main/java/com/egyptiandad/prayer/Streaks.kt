package com.egyptiandad.prayer

import java.time.LocalDate

/** Counts days on which all five prayers were marked as prayed. [done] holds keys like 2026-11-14:ASR. */
object Streaks {
    private const val DAYS = 400

    fun dayCount(done: Set<String>, date: LocalDate): Int =
        Prayer.values().count { done.contains("$date:${it.name}") }

    fun isComplete(done: Set<String>, date: LocalDate): Boolean =
        dayCount(done, date) == Prayer.values().size

    /** Consecutive full days. Today counts if it is already full, otherwise the streak ends yesterday. */
    fun current(done: Set<String>, today: LocalDate): Int {
        var day = if (isComplete(done, today)) today else today.minusDays(1)
        var n = 0
        while (n < DAYS && isComplete(done, day)) {
            n++
            day = day.minusDays(1)
        }
        return n
    }

    fun best(done: Set<String>, today: LocalDate): Int {
        var best = 0
        var run = 0
        for (i in (DAYS - 1) downTo 0) {
            if (isComplete(done, today.minusDays(i.toLong()))) {
                run++
                if (run > best) best = run
            } else {
                run = 0
            }
        }
        return best
    }

    fun totalFullDays(done: Set<String>, today: LocalDate): Int {
        var n = 0
        for (i in 0 until DAYS) {
            if (isComplete(done, today.minusDays(i.toLong()))) n++
        }
        return n
    }

    /** Prayers marked between [from] and [to], both included. */
    fun prayedBetween(done: Set<String>, from: LocalDate, to: LocalDate): Int {
        var n = 0
        var day = from
        while (!day.isAfter(to)) {
            n += dayCount(done, day)
            day = day.plusDays(1)
        }
        return n
    }

    /** Days between [from] and [to], both included, on which all five prayers were marked. */
    fun fullBetween(done: Set<String>, from: LocalDate, to: LocalDate): Int {
        var n = 0
        var day = from
        while (!day.isAfter(to)) {
            if (isComplete(done, day)) n++
            day = day.plusDays(1)
        }
        return n
    }
}
