package com.egyptiandad.prayer

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.chrono.HijrahDate
import java.time.format.DateTimeFormatter
import java.time.format.DecimalStyle

private val timeFormat: DateTimeFormatter = DateTimeFormatter.ofPattern("h:mm a", arabicLocale)
    .withDecimalStyle(DecimalStyle.of(arabicLocale))
    .withZone(PrayerTimes.zone)

fun formatTime(ms: Long): String = timeFormat.format(Instant.ofEpochMilli(ms))

fun countdown(ms: Long): String {
    val s = maxOf(0L, ms / 1000)
    return String.format(arabicLocale, "%02d:%02d:%02d", s / 3600, s % 3600 / 60, s % 60)
}

private fun dateLine(today: java.time.LocalDate): String {
    val gregorian = runCatching {
        DateTimeFormatter.ofPattern("EEEE d MMMM", arabicLocale).format(today)
    }.getOrDefault("")
    val hijri = runCatching {
        DateTimeFormatter.ofPattern("d MMMM yyyy", arabicLocale).format(HijrahDate.from(today))
    }.getOrDefault("")
    return if (hijri.isEmpty()) gregorian else "$gregorian · $hijri هـ"
}

@Composable
fun TimesScreen() {
    val ctx = LocalContext.current
    val prefs = remember { Prefs(ctx) }
    var version by remember { mutableIntStateOf(0) }
    @Suppress("UNUSED_VARIABLE")
    val refreshTick = version

    val now by produceState(System.currentTimeMillis()) {
        while (true) {
            value = System.currentTimeMillis()
            delay(1000)
        }
    }

    val today = PrayerTimes.today(now)
    val city = Cities.of(prefs)
    val events = remember(city, today) { PrayerTimes.events(city, today) }
    val next = events.firstOrNull { it.start > now }
    val prev = events.lastOrNull { it.start <= now }
    val active = events.lastOrNull { it.start <= now && now < it.end }
    val done = prefs.prayedSet()
    val todayPrayed = events.count { it.date == today && done.contains(it.key) }

    val notifOk = Notifier.hasPermission(ctx)
    val alarmManager = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val exactOk = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || alarmManager.canScheduleExactAlarms()

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        Scheduler.scheduleNext(ctx)
    }

    // Ask for the notification permission once, the first time the screen opens (Android 13+).
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && !Notifier.hasPermission(ctx)) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    fun mark(key: String, value: Boolean) {
        prefs.setPrayed(key, value)
        if (value) Notifier.cancel(ctx, key)
        version++
        Scheduler.scheduleNext(ctx)
    }

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(
                city.arabic + "  ·  " + dateLine(today),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 13.sp
            )
            Text(
                "ربنا يجعل يومك عامر بالطاعة",
                color = Gold.GoldLight,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Gold.Surface),
                border = BorderStroke(1.dp, Gold.Line)
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("صلوات تمّت", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    Text(arabicNumber(todayPrayed) + " / ٥", color = Gold.Gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
            Card(
                modifier = Modifier.weight(1f),
                colors = CardDefaults.cardColors(containerColor = Gold.Surface),
                border = BorderStroke(1.dp, Gold.Line)
            ) {
                Column(Modifier.fillMaxWidth().padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("متبقي اليوم", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
                    Text(arabicNumber((5 - todayPrayed).coerceAtLeast(0)), color = Gold.GoldLight, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Gold.Surface),
            border = BorderStroke(1.dp, Gold.Line)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("إنجازك في صلوات النهارده", color = Gold.GoldLight, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    Text(arabicNumber(todayPrayed * 20) + "٪", color = Gold.Gold, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
                LinearProgressIndicator(
                    progress = { todayPrayed / 5f },
                    modifier = Modifier.fillMaxWidth().height(7.dp).clip(RoundedCornerShape(50)),
                    color = Gold.Gold,
                    trackColor = Gold.Line
                )
                Text(
                    if (todayPrayed == 5) "ما شاء الله، أتممت صلوات اليوم. تقبّل الله منك 🤍" else "كل صلاة بتقرّبك خطوة… ربنا يتقبّل منك",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 11.sp
                )
            }
        }

        if (!notifOk) {
            NoticeCard("لازم تسمح بالإشعارات عشان التنبيه يظهر لك، حتى والشاشة مقفولة.") {
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }) { Text("اسمح بالإشعارات") }
                TextButton(onClick = {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                            .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    )
                }) { Text("افتح الإعدادات") }
            }
        }

        if (!exactOk) {
            NoticeCard("اسمح بالمنبهات الدقيقة عشان التنبيه يجيلك في الدقيقة بالظبط.") {
                Button(onClick = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + ctx.packageName))
                        )
                    }
                }) { Text("اسمح بالمنبهات") }
            }
        }

        // Next prayer
        val heroShape = RoundedCornerShape(24.dp)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(heroShape)
                .background(Brush.verticalGradient(listOf(Gold.SurfaceHigh, Gold.Surface)))
                .border(1.dp, Gold.GoldDark.copy(alpha = 0.7f), heroShape)
        ) {
            MosqueSilhouette(modifier = Modifier.align(Alignment.BottomCenter).alpha(0.16f))
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("الصلاة الجاية", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
                if (next != null) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(next.prayer.arabic, color = Gold.Gold, fontSize = 40.sp, fontWeight = FontWeight.Bold)
                        Text(formatTime(next.start), color = Gold.Ink, fontSize = 18.sp)
                    }
                    Text(
                        countdown(next.start - now),
                        color = Gold.GoldLight,
                        fontSize = 32.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    if (prev != null) {
                        val target = ((now - prev.start).toFloat() / (next.start - prev.start).toFloat()).coerceIn(0f, 1f)
                        val fraction by animateFloatAsState(targetValue = target, label = "progress")
                        LinearProgressIndicator(
                            progress = { fraction },
                            modifier = Modifier.fillMaxWidth(),
                            color = Gold.Gold,
                            trackColor = Gold.Line
                        )
                    }
                    Box(modifier = Modifier.padding(bottom = 64.dp))
                }
            }
        }

        // The prayer that is running now and has not been marked
        if (active != null && prefs.remindersOn && !done.contains(active.key)) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
                border = BorderStroke(1.dp, Gold.GoldDark)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("حان وقت " + active.prayer.arabic, color = Gold.Gold, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text(
                            "الوقت لحد " + formatTime(active.end),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 13.sp
                        )
                    }
                    Button(onClick = { mark(active.key, true) }) { Text("صلّيت") }
                }
            }
        }

        // Today's prayers, plus last night's Isha while it is still running after midnight
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = BorderStroke(1.dp, Gold.Line)
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                val rows = ArrayList<PrayerEvent>()
                if (active != null && active.date != today) rows.add(active)
                rows.addAll(events.filter { it.date == today })

                rows.forEachIndexed { index, e ->
                    val isPrayed = done.contains(e.key)
                    val isActive = active != null && active.key == e.key
                    val carry = e.date != today
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    e.prayer.arabic + if (carry) " (إمبارح)" else "",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (isActive) Gold.Gold else MaterialTheme.colorScheme.onSurface
                                )
                                if (isActive) {
                                    Text(
                                        "دلوقتي",
                                        fontSize = 11.sp,
                                        color = Gold.Gold,
                                        modifier = Modifier
                                            .border(1.dp, Gold.Gold, RoundedCornerShape(50))
                                            .padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(formatTime(e.start), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        when {
                            isPrayed -> FilledTonalButton(onClick = { mark(e.key, false) }) { Text("تمّت ✓") }
                            e.start <= now -> Button(onClick = { mark(e.key, true) }) { Text("صلّيت") }
                            else -> OutlinedButton(onClick = {}, enabled = false) { Text("لسه") }
                        }
                    }
                    if (index < rows.lastIndex) HorizontalDivider()
                }
            }
        }

        Text(
            "المواقيت محسوبة بطريقة الهيئة المصرية العامة للمساحة وممكن تفرق كام دقيقة عن تقويم المسجد. زرار \"لسه\" بيتفتح لما وقت الصلاة يدخل.",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}

@Composable
private fun NoticeCard(text: String, actions: @Composable () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer),
        border = BorderStroke(1.dp, Gold.GoldDark)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(text, color = MaterialTheme.colorScheme.onSecondaryContainer)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { actions() }
        }
    }
}
